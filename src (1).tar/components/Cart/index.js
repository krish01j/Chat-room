import Header from '../Header'
import ChatSection from '../ChatSection'
import './index.css'

const Cart = () => (
  <>
    <Header />
    <div className="cart-container">
      <ChatSection />
    </div>
  </>
)

export default Cart
