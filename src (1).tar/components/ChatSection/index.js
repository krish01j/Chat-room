import {Component} from 'react'
import UserProfile from '../UserProfile'

const initialUserDetailsList = [
  {
    uniqueNo: 1,
    imageUrl: 'https://assets.ccbp.in/frontend/react-js/esther-howard-img.png',
    name: 'Esther Howard',
    role: 'SChool friend',
  },
  {
    uniqueNo: 2,
    imageUrl: 'https://assets.ccbp.in/frontend/react-js/floyd-miles-img.png',
    name: 'Floyd Miles',
    role: 'Office pal',
  },
  {
    uniqueNo: 3,
    imageUrl: 'https://assets.ccbp.in/frontend/react-js/jacob-jones-img.png',
    name: 'Jacob Jones',
    role: 'Neighbor',
  },
  {
    uniqueNo: 4,
    imageUrl: 'https://assets.ccbp.in/frontend/react-js/devon-lane-img.png',
    name: 'Devon Lane',
    role: 'Manager',
  },
]

class ChatSection extends Component {
  render() {
    return (
      <ul className="list-container">
        {initialUserDetailsList.map(eachUser => (
          <UserProfile userDetails={eachUser} key={eachUser.uniqueNo} />
        ))}
      </ul>
    )
  }
}

export default ChatSection
