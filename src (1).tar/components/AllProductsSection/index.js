import {Component} from 'react'

import './index.css'

class AllProductsSection extends Component {
  state = {
    text: '',
  }

  changeState = event => {
    this.setState({text: event.target.value})
  }

  render() {
    const {text} = this.state
    return (
      <>
        <div>
          <p>{text}</p>
        </div>
        <div>
          <h1 className="head">Chat Room</h1>
        </div>

        <div className="displayText">
          <label htmlFor="username">Enter the message:</label>
          <input
            type="text"
            id="username"
            name="username"
            onChange={this.changeState}
          />

          <button type="submit" onClick={this.changeState}>
            Submit
          </button>
        </div>
      </>
    )
  }
}

export default AllProductsSection
