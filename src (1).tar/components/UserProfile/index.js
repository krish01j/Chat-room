import {Link} from 'react-router-dom'
import './index.css'

const UserProfile = props => {
  const {userDetails} = props
  const {imageUrl, name, role, uniqueNo} = userDetails

  return (
    <li className="user-card-container">
      <img src={imageUrl} className="profile-pic" alt="profile-pic" />
      <div className="user-details-container">
        <h1 className="user-name"> {name} </h1>
        <p className="user-designation"> {role} </p>
        <Link to="/products">
          <button type="button" className="shop-now-button">
            Enter Chat Room
          </button>
        </Link>
      </div>
    </li>
  )
}

export default UserProfile
